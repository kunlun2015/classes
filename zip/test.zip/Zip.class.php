<?php
/**
 * 解压缩包
 * @authors Kunlun (735767227@qq.com)
 * @date    2016-04-14 17:09:22
 * @copyright Kunlun
 */

$zip = new ZipArchive; 
var_dump($zip);